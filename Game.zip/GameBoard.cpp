/*******************************************************
 * GameBoard.cpp
 * Class defining the board where the player is moving, 
 * finds items and fight enemies
 * Uses a function to initialise the board
 *
 * author: Archit Arora
 * last modified 2020-12-18 
 ********************************************************/

#include <cstdlib>
#include <iostream>

#include "GameBoard.h"
#include "RandomGenerator.h"

using namespace std;

///////////////////
// CONSTRUCTORS //
/////////////////

// default constructor
GameBoard::GameBoard()
  :difficulty(2), maxColumns(200), maxRows(200)
{
  
}

// Custom constructor, depending of the columns and rows size and chosen difficulty
GameBoard::GameBoard(int select_diff, int columns, int rows)
  :difficulty(select_diff), maxColumns(columns), maxRows(rows)
{

}

/////////////////
// DESTRUCTOR //
///////////////

GameBoard::~GameBoard()
{

}

////////////////////////////
// INITIALISATION METHOD //
//////////////////////////

//////////////////////////////////////////////////////////////////////////
// function setItem(Type category)
// initialise the board with either an item, an enemy or nothing
// with the help of the class RandomGenerator to chose randomly
// the ratio between empty squares, items and enemy is dependant
// of the difficulty chosed by the player
//
// An object of the class RandomGenerator is created in the class definition
// of the class Board (header file), named "generator"
//
// parameter: N/A
// return: void
//////////////////////////////////////////////////////////////////////////
void GameBoard::initialise()
{
  int tile;
  // for each tile of the board
  for (int i=0; i<maxColumns; i++) { // for each columns
    for (int j=0; j<maxRows; j++) { // for each rows
      // put either and item, an enemy or nothing
      // use the function boardGenerator of the class RandomGenerator
      // to randomly chose what goes in a square of the board
      tile = generator.boardGenerator(difficulty);
      switch(tile) {
      case 1: // if the random function returns 1 
	// generate an enemy (ID 1 to 5)
	// thanks to the function characterGenerator
	worldMap[i][j] = generator.characterGenerator();
	break;
      case 2: // if the random function returns 2
	// generate an item (ID 6 to 13)
	// using the function itemGenerator
	worldMap[i][j] = generator.itemGenerator();
	break;
      case 3: // if the random function returns 3
      default:
	// The tile is empty (ID 0)
	worldMap[i][j] = 0;
	break;
      }
    }
  }
  return;
}
