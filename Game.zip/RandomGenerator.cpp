/*********************************************************
 * RandomGenerator.cpp
 * Class used by other classes in their function when a
 * random action is needed
 *
 * author: Archit Arora
 * last modified: 2020-12-23
 *********************************************************/

#include <cstdlib>
#include <iomanip>

#include "RandomGenerator.h"

using namespace std;

//////////////////
// Constructor //
////////////////

/////////////////////////////////////////////////////////////
// default constructor
// random number generator returning numbers from 0 to 100
//
// parameter: none
/////////////////////////////////////////////////////////////
RandomGenerator::RandomGenerator()
:minVal(1), maxVal(100)
{
  // use the system's time as a seed
  srand(time(nullptr)); 
}

/////////////////
// Destructor //
///////////////

RandomGenerator::~RandomGenerator()
{

}

////////////////////
// OTHER METHODS //
//////////////////

/////////////////////////////////////////////////////////////
// boardGenerator(difficulty)
// generate a random number between 1 and 100 (inclusive)
// this determines what type the square will be:
// - enemy, item or empty
//
// parameters: difficulty - int to know the ratio of items and enemy on the board
// return: writtenValue - int for what type the board square will contain
/////////////////////////////////////////////////////////////
int RandomGenerator::boardGenerator(int difficulty)
{
  // percentage thresholds for items and enemy
  int percentRace;
  int percentItem;
  // used for the random number
  int squareValue;
  // return variable (3 for empty, 2 for item, 1 for enemy) 
  int writtenValue;
 
  // will take difficulty level and return the percentage chance of
  // randomly returning race, item or empty square
  
  if (difficulty == 1) { // easy
    percentRace = 25; // 25% chance
    percentItem = 85; // between 26 and 85
  } else  if (difficulty == 2) { // medium
    percentRace = 25; // 25% chance
    percentItem = 50; // between 26 and 50
  } else { // if (difficulty == 3) -- hard
    percentRace = 60; // 60% chance
    percentItem = 85; // between 61 and 85
  }

  // random number generator between 1 and 100 (inclusive)
  squareValue = minVal + rand() % ((maxVal - minVal) +1);

  // will return 1 for race if random number is less than race percentage 
  if (squareValue <= percentRace) {
    writtenValue = 1;
  } else if (percentRace < squareValue && squareValue <= percentItem) {
    // will return 2 for item if random number is less than Item percentage
    writtenValue = 2;
  } else {
    // will return 3 for empty if random value is higher
    writtenValue = 3;
  }

  // will return the value of what type the square will be
  return writtenValue;
}

/////////////////////////////////////////////////////////////
// characterGenerator()
// returns a random number between 1 and 5 (inclusive)
// that will select which character fills the space
//
// parameter: none
// return: characterNumber - int for what type of character it will be
/////////////////////////////////////////////////////////////

int RandomGenerator::characterGenerator()
{

  // return variable
  int characterNumber;
  
  // will take random number from 1 to 5 (inclusive)
  // this will determine which character is on board
  characterNumber = minCharacter + rand() % ((maxCharacter - minCharacter) +1);

  /*
   * 1 = Human
   * 2 = Elf
   * 3 = Dwarf
   * 4 = Hobbit
   * 5 = Orc
   */
  
  // will return the type of the character to fill the square
  return characterNumber;
}

/////////////////////////////////////////////////////////////
// itemGenerator()
// returns a random number between 6 and 13 (inclusive)
// that will select which item fills the space
//
// parameter: none
// return: itemNumber - int for what type of item it will be
/////////////////////////////////////////////////////////////

int RandomGenerator::itemGenerator()
{

  // return variable
  int itemNumber;

  // will take random number from 6 to 13 (inclusive)
  // this will determine which item is on board
  itemNumber = minItem + rand() % ((maxItem - minItem) +1);

  /*
   * 6 = Sword (Weapon)
   * 7 = Dagger (Weapon)
   * 8 = Plate armour (Armour)
   * 9 = Leather armour (Armour)
   * 10 = Large shield (Shield)
   * 11 = Small shield (Shield)
   * 12 = Ring of life (Ring)
   * 13 = Ring of strength (Ring)
   */
  
  // will return the name of the item to fill the square
  return itemNumber;
}

/////////////////////////////////////////////////////////////
// combatGenerator()
// returns a random int between 1 and 100 (inclusive)
// that will define if an attack/defence is successful
//
// param: none
// return: combatNumber - int to know if action is a success or not
/////////////////////////////////////////////////////////////
int RandomGenerator::combatGenerator()
{
  // return variable
  int combatNumber;

  // randomly chose a number between 0 and 100
  combatNumber = minVal + rand() % ((maxVal - minVal) +1);
  
  return combatNumber;
}

/////////////////////////////////////////////////////////////
// hobbitSpecialDamage()
// returns a random int between 0 and 5 (inclusive)
// that will define the damage taken by a hobbit when
// he successfully defend against an attack
//
// param: none
// return: damage - int to know the damage taken
/////////////////////////////////////////////////////////////
int RandomGenerator::hobbitSpecialDamage()
{
  // return variable
  int damage;

  // randomly chose a number between 0 and 5 (inclusive)
  damage = rand() % 5;
  
  return damage;
}
