/*********************************************************************************
 * Items.cpp
 * Class defining items that can be picked up by the player
 * defines the statistics of the item and use a function to display those stats
 *
 * author: Archit Arora
 * last modified: 2020-12-20
 *********************************************************************************/

#include <cstdlib>
#include <iostream>

#include "Items.h"

using namespace std;

///////////////////
// CONSTRUCTORS //
/////////////////

// Default constructor
Items::Items()
  :attackBonus(5), healthBonus(0), strengthBonus(0), defenceBonus(0), itemWeight(5),
   itemType(Type::DAGGER)
{
  
}

// Custom constructor, depending of the type
Items::Items(Type category)
{
  // define the type of item
  itemType = category;
  // defines the stats of the items accordingly
  switch(category) {
  case Type::SWORD:
    attackBonus = 10;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 0;
    itemWeight = 10;
    break;
  case Type::DAGGER:
    attackBonus = 5;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 0;
    itemWeight = 5;
    break;
  case Type::PLATE:
    attackBonus = -5;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 10;
    itemWeight = 40;
    break;
  case Type::LEATHER:
    attackBonus = 0;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 5;
    itemWeight = 20;
    break;
  case Type::LARGESHIELD:
    attackBonus = -5;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 10;
    itemWeight = 30;
    break;
  case Type::SMALLSHIELD:
    attackBonus = 0;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 5;
    itemWeight = 10;
     break;
  case Type::ROL:
    attackBonus = 0;
    healthBonus = 10;
    strengthBonus = 0;
    defenceBonus = 0;
    itemWeight = 1;
    break;
  case Type::ROS:
    attackBonus = 0;
    healthBonus = -10;
    strengthBonus = 50;
    defenceBonus = 5;
    itemWeight = 1;
    break;
  default:
    break;
  }
}

/////////////////
// DESTRUCTOR //
///////////////

Items::~Items()
{
  
}

//////////////
// MUTATOR //
////////////

//////////////////////////////////////////////////////////////////////////
// function setItem(Type category)
// modify an item's type and statistics
//
// parameter: category - Type type object, used to modify the type and stats
// return: void
//////////////////////////////////////////////////////////////////////////
void Items::setItem(Type category)
{
  // Update the type of the Item
  itemType = category;
  // Change the statistics depending of the new type
  switch(category) {
  case Type::SWORD: // if a sword
    attackBonus = 10;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 0;
    itemWeight = 10;
    break;
  case Type::DAGGER: // if a dagger
    attackBonus = 5;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 0;
    itemWeight = 5;
    break;
  case Type::PLATE: // if a Plate armor
    attackBonus = -5;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 10;
    itemWeight = 40;
    break;
  case Type::LEATHER: // if a leather armor
    attackBonus = 0;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 5;
    itemWeight = 20;
    break;
  case Type::LARGESHIELD: // if a large shield
    attackBonus = -5;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 10;
    itemWeight = 30;
    break;
  case Type::SMALLSHIELD: // if a small shield
    attackBonus = 0;
    healthBonus = 0;
    strengthBonus = 0;
    defenceBonus = 5;
    itemWeight = 10;
     break;
  case Type::ROL: // if a Ring of Life
    attackBonus = 0;
    healthBonus = 10;
    strengthBonus = 0;
    defenceBonus = 0;
    itemWeight = 1;
    break;
  case Type::ROS: // if a Ring of Strength
    attackBonus = 0;
    healthBonus = -10;
    strengthBonus = 50;
    defenceBonus = 5;
    itemWeight = 1;
    break;
  default:
    break;
  }
}

/////////////////////
// OTHER FUNCTION //
///////////////////

//////////////////////////////////////////////////////////////////////////
// function printItem(int itemInt)
// Print the characteristics of an item, depending of the ID in parameter
// the Item ID is defined in the board to know what item/character
// is in each square.
// ID list:
//     6 = sword
//     7 = dagger
//     8 = plate armor
//     9 = leather armor
//     10 = large shield
//     11 = small shield
//     12 = ring of life
//     13 = ring of strength
//
// parameter: itemInt - int for the item ID
// return: void
//////////////////////////////////////////////////////////////////////////
void Items::printItems(int itemInt) const
{
  // Used to print the item type in a std::cout
  string inventItem;

  // We only print the interesting stats
  // aka: the stats different from 0
  
  switch(itemInt) {
  case 6: // if a sword
    inventItem = "Sword";
    // print type, attack bonus and weight
    cout << inventItem << ", attack: " << attackBonus
	 << ", weight: " << itemWeight << endl;
    break;
  case 7: // if dagger
    inventItem = "Dagger";
    // print type, attack bonus and weight
    cout << inventItem << ", attack: " << attackBonus
	 << ", weight: " << itemWeight << endl;
    break;
  case 8: // if plate armor
    inventItem = "Plate Armour";
    // print type, attack malus, defence bonus and weight
    cout << inventItem << ", attack: " << attackBonus
	 << ", Defence: " << defenceBonus 
	 << ", weight: " << itemWeight << endl;
    break;
  case 9: // if leather armor
    inventItem = "Leather Armour";
    // print type, defence bonus and weight
    cout << inventItem << ", Defence: " << defenceBonus 
	 << ", weight: " << itemWeight << endl;
    break;
  case 10: // if large shield
    inventItem = "Large Shield";
    // print type, attack malus, defence bonus and weight
    cout << inventItem << ", attack: " << attackBonus
	 << ", Defence: " << defenceBonus 
	 << ", weight: " << itemWeight << endl;
    break;
  case 11: // if small shield
    inventItem = "Small Shield";
    // print type, defence bonus and weight
    cout << inventItem << ", Defence: " << defenceBonus 
	 << ", weight: " << itemWeight << endl;
    break;
  case 12: // if ring of lie
    inventItem = "Ring of Life";
    // print type, health bonus and weight
    cout << inventItem << ", Health: " << healthBonus 
	 << ", weight: " << itemWeight << endl;
    break;
  case 13: // if ring of strength
    inventItem = "Ring of Strength";
    // print type, strength bonus, health malus and weight
    cout << inventItem << ", Strength: " << strengthBonus
	 << ", Health: " << healthBonus
	 << ", weight: " << itemWeight << endl;
    break;
  default:
    break;
  }
}
